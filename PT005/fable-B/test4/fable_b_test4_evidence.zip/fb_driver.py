#!/usr/bin/env python3
"""
fb_driver.py -- Fable-B's own driver for PT005 TEST 4 (p = 239, K = 15).

Written from scratch by the testing seat. It does not use, read or import the
chair's kcascade_run.py or any chair output file.

What it does
  reducible branch  : bgk15 P km1roots ; bgk15 P km1root r FILE (every root)
                      -> union of all lines, deduplicated, sorted
                      -> cascade_k15p P filterext DEDUP_FILE
  irredundant branch: bgk15 P irroots ; bgk15 P irsubroots r (every root)
                      -> bgk15 P irsubrootrawc r s FILE (every job (r, s))
                      -> cascade_k15p P filter FILE

Resumable: one JSON line per finished job is appended to OUT/*.jsonl; a
finished job is never run again. Run it again after an interruption.

usage: fb_driver.py P WORKERS OUT [--km1-only] [--ir-only] [--limit=N]
"""
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from multiprocessing import Pool

HERE = os.path.dirname(os.path.abspath(__file__))
ENGINE = os.path.join(HERE, "bgk15")
CASCADE = os.path.join(HERE, "cascade_k15p")
K = 15

P = int(sys.argv[1])
WORKERS = int(sys.argv[2])
OUT = os.path.abspath(sys.argv[3])
FLAGS = sys.argv[4:]
NC = (P - 1) // 2
LIMIT = None
for f in FLAGS:
    if f.startswith("--limit="):
        LIMIT = int(f.split("=")[1])

for d in ("ir_rows", "ir_casc", "km1_rows", "km1_casc"):
    os.makedirs(os.path.join(OUT, d), exist_ok=True)

SURV_RE = re.compile(r"^SURVIVOR base:((?: \d+)+) l2=(\d+) tight=(YES|no)(.*)$")
LVL_RE = re.compile(r" l(\d+)=(\d+)")


def stamp():
    return time.strftime("%Y-%m-%d %H:%M:%S %z")


def say(msg):
    line = f"{stamp()} {msg}"
    print(line, flush=True)
    with open(os.path.join(OUT, "driver.log"), "a") as fh:
        fh.write(line + "\n")


def sh(cmd):
    t0 = time.time()
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r.stdout, r.stderr, r.returncode, time.time() - t0


def file_digest(path):
    h = hashlib.sha256()
    n = 0
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
            n += chunk.count(b"\n")
    return h.hexdigest(), n


def listing(args):
    """Parse an engine listing: header line, then 'index value' lines."""
    out, err, rc, _ = sh([ENGINE, str(P)] + args)
    if rc != 0:
        raise SystemExit(f"engine {args} rc={rc} {err[-300:]}")
    rows = out.splitlines()
    head = rows[0]
    idx = [int(x.split()[0]) for x in rows[1:] if x.strip()]
    val = [int(x.split()[1]) for x in rows[1:] if x.strip()]
    m = re.search(r"(?:sub)?roots=(\d+)", head)
    if not m or int(m.group(1)) != len(idx) or idx != list(range(len(idx))):
        raise SystemExit(f"listing {args}: header '{head}' does not match {len(idx)} entries")
    return head, idx, val


def read_cascade(stdout_text, stderr_text, ncls):
    """Tally one cascade run. Returns counts taken from its own output only."""
    m = re.search(r"TOTAL rows=(\d+) survivors=(\d+)", stderr_text)
    if not m:
        raise RuntimeError("no TOTAL line: " + stderr_text[-300:])
    tot_rows, tot_surv = int(m.group(1)), int(m.group(2))
    alive = {4: 0, 8: 0, 16: 0, 32: 0}      # rows with a non-zero count at that level
    cnt = {2: 0, 4: 0, 8: 0, 16: 0, 32: 0}  # sum of the printed lift counts
    seen = 0
    tight_yes = 0
    persistent = 0
    deepest = 0
    for line in stdout_text.splitlines():
        if not line:
            continue
        g = SURV_RE.match(line)
        if not g:
            raise RuntimeError("unparsed cascade line: " + line[:200])
        if len(g.group(1).split()) != ncls:
            raise RuntimeError("wrong class count: " + line[:200])
        seen += 1
        l2 = int(g.group(2))
        if l2 == 0:
            raise RuntimeError("survivor with l2=0: " + line[:200])
        cnt[2] += l2
        deepest = max(deepest, 2)
        tight_yes += g.group(3) == "YES"
        tail = g.group(4)
        if tail.rstrip().endswith("PERSISTENT"):
            persistent += 1
        for lv, n in LVL_RE.findall(tail):
            lv, n = int(lv), int(n)
            cnt[lv] += n
            if n > 0:
                alive[lv] += 1
                deepest = max(deepest, lv)
    if seen != tot_surv:
        raise RuntimeError(f"SURVIVOR lines {seen} != TOTAL survivors {tot_surv}")
    return dict(casc_rows=tot_rows, l2_survivors=tot_surv, alive_l4=alive[4], alive_l8=alive[8],
                alive_l16=alive[16], alive_l32=alive[32], persistent=persistent,
                sum_l2=cnt[2], sum_l4=cnt[4], sum_l8=cnt[8], sum_l16=cnt[16], sum_l32=cnt[32],
                deepest_level=deepest, tight_yes=tight_yes)


def do_ir(job):
    r, s = job
    tag = f"r{r:02d}_s{s:02d}"
    rows = os.path.join(OUT, "ir_rows", tag + ".rows")
    gout, gerr, rc, gwall = sh([ENGINE, str(P), "irsubrootrawc", str(r), str(s), rows])
    if rc != 0:
        return dict(branch="ir", r=r, s=s, error=f"engine rc={rc} {gerr[-300:]}")
    m = re.search(rf"root=(\d+) sub=(\d+) raw_irred{K}=(\d+) rawscan=(\d+) nodes=(\d+) leaves=(\d+) secs=([\d.eE+-]+)", gout)
    if not m or int(m.group(1)) != r or int(m.group(2)) != s:
        return dict(branch="ir", r=r, s=s, error="engine line unparsed: " + gout[-300:])
    digest, nlines = file_digest(rows)
    cout, cerr, crc, cwall = sh([CASCADE, str(P), "filter", rows])
    if crc != 0:
        return dict(branch="ir", r=r, s=s, error=f"cascade rc={crc} {cerr[-300:]}")
    open(os.path.join(OUT, "ir_casc", tag + ".out"), "w").write(cout)
    open(os.path.join(OUT, "ir_casc", tag + ".err"), "w").write(cerr)
    try:
        tally = read_cascade(cout, cerr, K)
    except RuntimeError as e:
        return dict(branch="ir", r=r, s=s, error=str(e))
    rec = dict(branch="ir", r=r, s=s, engine_line=gout.strip(), rows=int(m.group(3)),
               rawscan=int(m.group(4)), nodes=int(m.group(5)), leaves=int(m.group(6)),
               gen_secs=float(m.group(7)), gen_wall=round(gwall, 3), casc_wall=round(cwall, 3),
               rows_file_lines=nlines, rows_sha256=digest)
    rec.update(tally)
    if not (rec["rows"] == nlines == rec["casc_rows"]):
        rec["error"] = f"row counts disagree: engine {rec['rows']} file {nlines} cascade {rec['casc_rows']}"
    return rec


def do_km1(r):
    tag = f"km1_r{r:02d}"
    rows = os.path.join(OUT, "km1_rows", tag + ".rows")
    gout, gerr, rc, gwall = sh([ENGINE, str(P), "km1root", str(r), rows])
    if rc != 0:
        return dict(branch="km1", r=r, error=f"engine rc={rc} {gerr[-300:]}")
    m = re.search(rf"root=(\d+) canonical{K - 1}=(\d+) nodes=(\d+) leaves=(\d+) secs=([\d.eE+-]+)", gout)
    if not m or int(m.group(1)) != r:
        return dict(branch="km1", r=r, error="engine line unparsed: " + gout[-300:])
    digest, nlines = file_digest(rows)
    rec = dict(branch="km1", r=r, engine_line=gout.strip(), covers=int(m.group(2)), nodes=int(m.group(3)),
               leaves=int(m.group(4)), gen_secs=float(m.group(5)), gen_wall=round(gwall, 3),
               rows_file_lines=nlines, rows_sha256=digest)
    if rec["covers"] != nlines:
        rec["error"] = f"cover counts disagree: engine {rec['covers']} file {nlines}"
    return rec


def load(path, key):
    done = {}
    if os.path.exists(path):
        for line in open(path):
            line = line.strip()
            if not line:
                continue
            rec = json.loads(line)
            if "error" not in rec:
                done[key(rec)] = rec
    return done


def run_pool(fn, todo, path, label):
    if not todo:
        return
    t0 = time.time()
    n = 0
    with Pool(WORKERS) as pool, open(path, "a") as fh:
        for rec in pool.imap_unordered(fn, todo, chunksize=1):
            fh.write(json.dumps(rec, sort_keys=True) + "\n")
            fh.flush()
            os.fsync(fh.fileno())
            n += 1
            if "error" in rec:
                say(f"{label} JOB ERROR {rec}")
            else:
                say(f"{label} {n}/{len(todo)} done r={rec['r']} s={rec.get('s', '-')} "
                    f"rows={rec.get('rows', rec.get('covers'))} nodes={rec['nodes']} "
                    f"l2={rec.get('l2_survivors', '-')} alive16={rec.get('alive_l16', '-')} "
                    f"elapsed={time.time() - t0:.0f}s")


def main():
    say(f"START P={P} K={K} workers={WORKERS} out={OUT} flags={FLAGS}")
    info = sh([ENGINE, str(P), "info"])[0].strip()
    say("engine info: " + info)
    if f"K={K} " not in info:
        raise SystemExit("engine is not a K=15 build")

    # ---- reducible branch -------------------------------------------------
    if "--ir-only" not in FLAGS:
        head, kidx, kval = listing(["km1roots"])
        say(f"km1roots: {head} values={kval}")
        kpath = os.path.join(OUT, "km1_jobs.jsonl")
        done = load(kpath, lambda x: x["r"])
        run_pool(do_km1, [r for r in kidx if r not in done], kpath, "km1")
        done = load(kpath, lambda x: x["r"])
        if len(done) != len(kidx):
            raise SystemExit(f"km1: {len(done)}/{len(kidx)} roots finished")
        union = set()
        rooted = 0
        for r in kidx:
            for line in open(os.path.join(OUT, "km1_rows", f"km1_r{r:02d}.rows")):
                line = line.strip()
                if line:
                    rooted += 1
                    union.add(line)
        dedup = os.path.join(OUT, "km1_rows", "km1_dedup.rows")
        with open(dedup, "w") as fh:
            for line in sorted(union):
                fh.write(line + "\n")
        say(f"km1 union: rooted covers={rooted} distinct covers={len(union)}")
        cout, cerr, crc, cwall = sh([CASCADE, str(P), "filterext", dedup])
        if crc != 0:
            raise SystemExit(f"filterext rc={crc} {cerr[-300:]}")
        open(os.path.join(OUT, "km1_casc", "ext.out"), "w").write(cout)
        open(os.path.join(OUT, "km1_casc", "ext.err"), "w").write(cerr)
        tally = read_cascade(cout, cerr, K)
        summ = dict(branch="km1", P=P, K=K, roots=len(kidx), root_values=kval, rooted_covers=rooted,
                    distinct_covers=len(union), dedup_sha256=file_digest(dedup)[0],
                    ext_rows_expected=len(union) * NC, casc_wall=round(cwall, 3),
                    nodes_total=sum(done[r]["nodes"] for r in kidx),
                    gen_secs_total=round(sum(done[r]["gen_secs"] for r in kidx), 3),
                    per_root=[dict(r=r, covers=done[r]["covers"], nodes=done[r]["nodes"]) for r in kidx])
        summ.update(tally)
        summ["ok_ext_rows"] = (tally["casc_rows"] == len(union) * NC)
        json.dump(summ, open(os.path.join(OUT, "km1_summary.json"), "w"), indent=1, sort_keys=True)
        say("KM1 SUMMARY " + json.dumps({k: v for k, v in summ.items() if k != "per_root"}, sort_keys=True))

    # ---- irredundant branch ----------------------------------------------
    if "--km1-only" not in FLAGS:
        head, ridx, rval = listing(["irroots"])
        say(f"irroots: {head} values={rval}")
        jobs = []
        sublist = {}
        for r in ridx:
            h, sidx, sval = listing(["irsubroots", str(r)])
            sublist[r] = dict(header=h, values=sval)
            jobs += [(r, s) for s in sidx]
        json.dump(dict(root_values=rval, subroots=sublist), open(os.path.join(OUT, "ir_joblist.json"), "w"),
                  indent=1, sort_keys=True)
        say(f"irredundant jobs: {len(jobs)} over {len(ridx)} roots; per root {[len(sublist[r]['values']) for r in ridx]}")
        ipath = os.path.join(OUT, "ir_jobs.jsonl")
        done = load(ipath, lambda x: (x["r"], x["s"]))
        todo = [j for j in jobs if j not in done]
        if LIMIT is not None:
            todo = todo[:LIMIT]
        say(f"irredundant: {len(done)} already finished, {len(todo)} to run now")
        run_pool(do_ir, todo, ipath, "ir")
        done = load(ipath, lambda x: (x["r"], x["s"]))
        fin = [done[j] for j in jobs if j in done]
        summ = dict(branch="ir", P=P, K=K, jobs_total=len(jobs), jobs_finished=len(fin),
                    complete=(len(fin) == len(jobs)),
                    rows=sum(x["rows"] for x in fin), nodes=sum(x["nodes"] for x in fin),
                    l2_survivors=sum(x["l2_survivors"] for x in fin),
                    alive_l4=sum(x["alive_l4"] for x in fin), alive_l8=sum(x["alive_l8"] for x in fin),
                    alive_l16=sum(x["alive_l16"] for x in fin), alive_l32=sum(x["alive_l32"] for x in fin),
                    persistent=sum(x["persistent"] for x in fin),
                    deepest_level=max([x["deepest_level"] for x in fin] or [0]),
                    gen_secs_total=round(sum(x["gen_secs"] for x in fin), 1),
                    casc_wall_total=round(sum(x["casc_wall"] for x in fin), 1))
        json.dump(summ, open(os.path.join(OUT, "ir_summary.json"), "w"), indent=1, sort_keys=True)
        say("IR SUMMARY " + json.dumps(summ, sort_keys=True))
    say("END")


if __name__ == "__main__":
    main()
