#!/usr/bin/env python3
"""fb_compare.py -- step 5: Fable-B results vs the chair's files, job by job."""
import collections
import json
import sys

MINE = sys.argv[1]      # my OUT directory
CHAIR = sys.argv[2]     # chair's p239_full_cascade directory

mine = {}
for line in open(f"{MINE}/ir_jobs.jsonl"):
    d = json.loads(line)
    assert "error" not in d
    assert (d["r"], d["s"]) not in mine
    mine[(d["r"], d["s"])] = d
chair = {}
dup = 0
for line in open(f"{CHAIR}/ir_K15_p239.jsonl"):
    d = json.loads(line)
    dup += (d["r"], d["s"]) in chair
    chair[(d["r"], d["s"])] = d

print("IRREDUNDANT BRANCH")
print(f"  jobs: mine={len(mine)} chair={len(chair)} chair_duplicate_keys={dup}")
only_mine = sorted(set(mine) - set(chair))
only_chair = sorted(set(chair) - set(mine))
print(f"  jobs only in mine: {only_mine}")
print(f"  jobs only in chair: {only_chair}")

fields = [("rows", "rows"), ("nodes", "nodes"), ("casc_rows", "casc_rows"),
          ("l2_survivors", "casc_survivors"), ("l2_survivors", "n_survivor_lines")]
diff = collections.defaultdict(list)
deep_diff = []
for key in sorted(set(mine) & set(chair)):
    a, b = mine[key], chair[key]
    for fa, fb in fields:
        if a[fa] != b[fb]:
            diff[f"{fa}~{fb}"].append((key, a[fa], b[fb]))
    if a["alive_l16"] != len(b["deep"]):
        deep_diff.append((key, a["alive_l16"], len(b["deep"])))
for fa, fb in fields:
    name = f"{fa}~{fb}"
    print(f"  jobs where mine.{fa} != chair.{fb}: {len(diff[name])} {diff[name][:20]}")
print(f"  jobs where mine.alive_l16 != len(chair.deep): {len(deep_diff)} {deep_diff[:20]}")
rows_or_nodes = sorted(set(k for n in ("rows~rows", "nodes~nodes") for k, _, _ in diff[n]))
print(f"  JOBS WHERE rows OR nodes DIFFER: {len(rows_or_nodes)} {rows_or_nodes}")
common = sorted(set(mine) & set(chair))
for label, src, f_rows, f_nodes, f_l2, deepf in (
        ("mine ", mine, "rows", "nodes", "l2_survivors", lambda x: x["alive_l16"]),
        ("chair", chair, "rows", "nodes", "casc_survivors", lambda x: len(x["deep"]))):
    print(f"  totals {label}: jobs={len(src)} rows={sum(x[f_rows] for x in src.values())} "
          f"nodes={sum(x[f_nodes] for x in src.values())} "
          f"l2_survivors={sum(x[f_l2] for x in src.values())} "
          f"alive_l16={sum(deepf(x) for x in src.values())}")
print(f"  CPU secs (generation): mine={sum(x['gen_secs'] for x in mine.values()):.1f} "
      f"chair={sum(x['secs'] for x in chair.values()):.1f}")

print("REDUCIBLE BRANCH")
ms = json.load(open(f"{MINE}/km1_summary.json"))
cs = json.load(open(f"{CHAIR}/km1_K15_p239.json"))
pairs = [("roots", ms["roots"], cs["roots"]), ("distinct covers", ms["distinct_covers"], cs["covers"]),
         ("extension rows", ms["casc_rows"], cs["ext_rows"]),
         ("level-2 survivors", ms["l2_survivors"], cs["ext_survivors"])]
kbad = 0
for name, a, b in pairs:
    kbad += a != b
    print(f"  {name}: mine={a} chair={b} {'same' if a == b else 'DIFFERENT'}")
my_lines = [l.rstrip("\n") for l in open(f"{MINE}/km1_casc/ext.out") if l.strip()]
ch_lines = cs["survivor_lines"]
same_order = my_lines == ch_lines
same_multiset = collections.Counter(my_lines) == collections.Counter(ch_lines)
print(f"  SURVIVOR lines: mine={len(my_lines)} chair={len(ch_lines)} identical_in_order={same_order} "
      f"identical_as_multiset={same_multiset}")
ch16 = [l for l in ch_lines if " l16=" in l and " l16=0" not in l]
print(f"  alive at level 16: mine={ms['alive_l16']} chair={len(ch16)}")
print(f"  CPU secs (generation): mine={ms['gen_secs_total']} chair={cs['gen_secs']:.1f}")
print("  note: the chair's km1 file has no per-root rows/nodes, so these cannot be compared root by root")

ok = (not only_mine and not only_chair and not dup and not rows_or_nodes and not deep_diff
      and all(len(v) == 0 for v in diff.values()) and kbad == 0 and same_multiset
      and ms["alive_l16"] == len(ch16) and len(mine) == 149)
print("VERDICT:", "MATCH" if ok else "MISMATCH")
