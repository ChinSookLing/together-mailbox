#!/usr/bin/env python3
"""
fb_altcheck.py -- EXTRA (not asked for in the packet): repeat a SAMPLE with a
different compiler and a different code path of the same unmodified sources.

  main run : g++ 13, -march=native  -> engine prints VEC=1 (AVX-512 path)
  this run : clang++ 18, -march=x86-64-v3 -> engine prints VEC=0 (scalar path)

Sample: all 14 km1 roots + 20 irredundant jobs drawn with
random.Random(239).sample(all 149 jobs in (r, s) order, 20).
Every generated rows file must be byte-identical (sha256) to the main run's,
nodes must be equal, and the clang cascade must print the same SURVIVOR lines.
"""
import hashlib
import json
import os
import random
import re
import subprocess
import sys
from multiprocessing import Pool

HERE = os.path.dirname(os.path.abspath(__file__))
ENG = os.path.join(HERE, "bgk15_clang_novec")
CAS = os.path.join(HERE, "cascade_k15p_clang")
OUT = os.path.join(HERE, "out")
ALT = os.path.join(OUT, "alt")
os.makedirs(ALT, exist_ok=True)
P = "239"


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)


def ir(job):
    r, s, ref = job
    f = os.path.join(ALT, f"r{r:02d}_s{s:02d}.rows")
    g = run([ENG, P, "irsubrootrawc", str(r), str(s), f]).stdout
    m = re.search(r"raw_irred15=(\d+) rawscan=(\d+) nodes=(\d+) leaves=(\d+)", g)
    c = run([CAS, P, "filter", f])
    main_out = open(os.path.join(OUT, "ir_casc", f"r{r:02d}_s{s:02d}.out")).read()
    res = dict(kind="ir", r=r, s=s, rows=int(m[1]), nodes=int(m[3]),
               rows_same=int(m[1]) == ref["rows"], nodes_same=int(m[3]) == ref["nodes"],
               file_same=sha(f) == ref["rows_sha256"], cascade_same=c.stdout == main_out)
    os.remove(f)
    return res


def km1(job):
    r, ref = job
    f = os.path.join(ALT, f"km1_r{r:02d}.rows")
    g = run([ENG, P, "km1root", str(r), f]).stdout
    m = re.search(r"canonical14=(\d+) nodes=(\d+)", g)
    res = dict(kind="km1", r=r, rows=int(m[1]), nodes=int(m[2]),
               rows_same=int(m[1]) == ref["covers"], nodes_same=int(m[2]) == ref["nodes"],
               file_same=sha(f) == ref["rows_sha256"], cascade_same=True)
    os.remove(f)
    return res


def main():
    irref = {}
    for line in open(os.path.join(OUT, "ir_jobs.jsonl")):
        d = json.loads(line)
        irref[(d["r"], d["s"])] = d
    kref = {}
    for line in open(os.path.join(OUT, "km1_jobs.jsonl")):
        d = json.loads(line)
        kref[d["r"]] = d
    pick = sorted(random.Random(239).sample(sorted(irref), 20))
    print("engine info:", run([ENG, P, "info"]).stdout.strip())
    print("sampled ir jobs:", pick, flush=True)
    res = []
    with Pool(2) as pool:
        for x in pool.imap_unordered(km1, [(r, kref[r]) for r in sorted(kref)]):
            res.append(x)
            print(json.dumps(x), flush=True)
        for x in pool.imap_unordered(ir, [(r, s, irref[(r, s)]) for r, s in pick]):
            res.append(x)
            print(json.dumps(x), flush=True)
    c = run([CAS, P, "filterext", os.path.join(OUT, "km1_rows", "km1_dedup.rows")])
    ext_same = c.stdout == open(os.path.join(OUT, "km1_casc", "ext.out")).read()
    bad = [x for x in res if not (x["rows_same"] and x["nodes_same"] and x["file_same"] and x["cascade_same"])]
    nir = sum(x["kind"] == "ir" for x in res)
    print(f"ALTCHECK km1_roots={len(res) - nir} ir_jobs={nir} ir_rows={sum(x['rows'] for x in res if x['kind'] == 'ir')} "
          f"differing_jobs={len(bad)} filterext_output_identical={ext_same}")
    sys.exit(1 if bad or not ext_same else 0)


if __name__ == "__main__":
    main()
