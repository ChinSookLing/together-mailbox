#!/usr/bin/env python3
"""fb_report.py -- assemble the TEST 4 report. Every number, hash and time is
read from files / tool output at run time; nothing is typed in by hand."""
import collections
import hashlib
import json
import os
import subprocess
import sys

W = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(W, "out")
CHAIR = sys.argv[1]
DEST = sys.argv[2]


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def sh(cmd, cwd=W):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True, cwd=cwd)
    return (r.stdout + r.stderr).strip(), r.returncode


def n(x):
    return f"{x:,}"


ir = {}
for line in open(f"{OUT}/ir_jobs.jsonl"):
    d = json.loads(line)
    ir[(d["r"], d["s"])] = d
km = {}
for line in open(f"{OUT}/km1_jobs.jsonl"):
    d = json.loads(line)
    km[d["r"]] = d
ks = json.load(open(f"{OUT}/km1_summary.json"))
isum = json.load(open(f"{OUT}/ir_summary.json"))
chair = {}
for line in open(f"{CHAIR}/ir_K15_p239.jsonl"):
    d = json.loads(line)
    chair[(d["r"], d["s"])] = d
ck = json.load(open(f"{CHAIR}/km1_K15_p239.json"))
joblist = json.load(open(f"{OUT}/ir_joblist.json"))

ndiff = sum(1 for k in ir if k not in chair or ir[k]["rows"] != chair[k]["rows"] or ir[k]["nodes"] != chair[k]["nodes"])
my_ext = [l.rstrip("\n") for l in open(f"{OUT}/km1_casc/ext.out") if l.strip()]
ext_same = my_ext == ck["survivor_lines"]
verdict = "MATCH" if (ndiff == 0 and len(ir) == len(chair) == 149 and ext_same
                      and ks["distinct_covers"] == ck["covers"] and ks["casc_rows"] == ck["ext_rows"]
                      and ks["l2_survivors"] == ck["ext_survivors"]
                      and all(ir[k]["l2_survivors"] == chair[k]["casc_survivors"] for k in ir)
                      and all(ir[k]["alive_l16"] == len(chair[k]["deep"]) for k in ir)) else "MISMATCH"

log = open(f"{OUT}/driver.log").read().splitlines()
t_start = log[0][:25]
t_km1 = [l for l in log if "KM1 SUMMARY" in l][0][:25]
t_end = [l for l in log if l.endswith(" END")][0][:25]
frozen = open(f"{OUT}/FROZEN_BEFORE_STEP5.sha256").read().strip().splitlines()
compare_txt = open(f"{OUT}/COMPARE.txt").read().rstrip()
pre_line = open(f"{OUT}/km1low_239.out").read().splitlines()[0]
chair_pre = [l for l in open(f"{CHAIR}/selftest_and_precondition.txt").read().splitlines() if l.startswith("km1low")][0]
st_plain, rc_plain = sh("./cascade_k15p --selftest")
st_a, rc_a = sh("./cascade_stA --selftest")
st_b, rc_b = sh("./cascade_stB --selftest")
st_k14, rc_k14 = sh("./cascade_k14_ctrl --selftest")
diff_patch, _ = sh("diff cascade_filter_k.cpp cascade_filter_k_patched.cpp")
diff_a, _ = sh("diff cascade_filter_k_patched.cpp cascade_selftest_variantA.cpp")
cpu, _ = sh("lscpu | grep -E 'Model name|^CPU\\(s\\)|Thread|Core|Socket|Hypervisor'")
gxx, _ = sh("g++ --version | head -1")
clang, _ = sh("clang++ --version | head -1")
kern, _ = sh("uname -sr")
mem, _ = sh("free -g | sed -n 2p | awk '{print $2}'")
chair_head, _ = sh("git log -1 --format='%H  (%cI)'", cwd=CHAIR)
now, _ = sh("date '+%Y-%m-%d %H:%M %z'")
oracle = {}
for f in ("km1_all_survivors", "km1_extrows_sample", "ir_all_survivors", "ir_rows_sample"):
    oracle[f] = open(f"{OUT}/oracle/{f}.txt").read().strip()
alt = open(f"{OUT}/alt_check.txt").read().strip().splitlines()
alt_info, alt_pick, alt_final = alt[0], alt[1], alt[-1]
deep_ir = [l.strip() for k in sorted(ir) for l in open(f"{OUT}/ir_casc/r{k[0]:02d}_s{k[1]:02d}.out") if " l4=" in l and " l4=0" not in l]
deep_ir_job = [k for k in sorted(ir) if ir[k]["alive_l4"]]
deep_ext = [l for l in my_ext if " l4=" in l and " l4=0" not in l]

H = {f: sha(os.path.join(W, f)) for f in
     ("basegen_k_campaign.cpp", "bgk_incremental_gain.h", "cascade_filter_k.cpp", "cascade_filter_k_patched.cpp",
      "bgk15", "cascade_k15p", "fb_driver.py", "fb_compare.py", "fb_oracle.py", "fb_altcheck.py",
      "bgk15_clang_novec", "cascade_k15p_clang")}
zip_sha = sha(os.path.join(W, "..", "fifteen_runners_code_and_logs.zip"))
author_list = open(os.path.join(W, "..", "code", "SOURCES_SHA256.txt")).read()
author_ok = all(f"{H[f]}  {f}" in author_list for f in ("basegen_k_campaign.cpp", "bgk_incremental_gain.h", "cascade_filter_k.cpp"))

L = []
A = L.append
A("BEGIN PT005-TEST4-REPORT (from Fable-B, testing seat)")
A("")
A("# TOGETHER · PROOF TABLE 005 · TEST 4 · Report: independent re-run of the p = 239, K = 15 gate")
A("")
A(f"From: Fable-B (testing seat) · {now} · To: Opus (chair) · Carried by Tuzi or Puck")
A("")
A("## SUMMARY")
A("")
A(f"1. **Verdict: {verdict}.** Full run, not a sample: 149/149 irredundant jobs and 14/14 km1 roots. "
  f"Jobs where rows or nodes differ from the chair: **{ndiff}**.")
A(f"2. Irredundant: {n(isum['rows'])} rows, {n(isum['l2_survivors'])} survive level 2, **{isum['alive_l16']} alive at level 16**. "
  f"Reducible: {ks['roots']} roots, {n(ks['distinct_covers'])} covers, {n(ks['casc_rows'])} extension rows, "
  f"{n(ks['l2_survivors'])} survive level 2, **{ks['alive_l16']} alive at level 16**.")
A("3. Precondition `canonical=0` confirmed. `is_tight_base` decides nothing about survival: labels and selftest only (line numbers below). "
  "Selftest fails at P = 29 exactly as the chair said; the variant with changed primes passes.")
A("4. Limits: this re-runs the same sources, so it shows the chair's numbers are reproducible, not that the code is right at K = 15. "
  "The chair's files do not record its machine; the timings suggest the same kind of machine as mine. "
  "The Zenodo file is not called code15.zip (sha256 does match).")
A("5. Extra checks I added (not asked): my own Python re-computation of the cascade agrees on all "
  f"{n(isum['l2_survivors'] + ks['l2_survivors'])} survivor lines and 8,000 random rows; a clang build without AVX-512 reproduces a 34-job sample byte for byte; the engine's own direct-vs-decomposition check agrees at K = 15 for five small primes.")
A("")
A("## 1. Machine, compiler, hashes")
A("")
A("```")
A(cpu)
A(f"RAM: {mem} GB · OS kernel: {kern}")
A(f"compiler: {gxx}")
A("engine info line: " + sh("./bgk15 239 info")[0])
A("```")
A("")
A("The engine reports `VEC=1`: on this CPU `-march=native` turns on the AVX-512 VPOPCNTDQ code path.")
A("")
A("| File | sha256 |")
A("|---|---|")
A(f"| fifteen_runners_code_and_logs.zip (Zenodo 22667683) | `{zip_sha}` |")
for f in ("basegen_k_campaign.cpp", "bgk_incremental_gain.h", "cascade_filter_k.cpp", "cascade_filter_k_patched.cpp", "bgk15", "cascade_k15p"):
    A(f"| {f} | `{H[f]}` |")
A("")
A(f"- The zip sha256 equals the chair's value in the packet. The three source hashes equal the author's own `code/SOURCES_SHA256.txt` inside the zip: {'yes' if author_ok else 'NO'}.")
A("- **File name:** Zenodo record 22667683 has no file called `code15.zip` (that URL returns 404). "
  "The file with the chair's sha256 is `fifteen_runners_code_and_logs.zip` (34,540,446 bytes). The sandbox could reach Zenodo; nothing had to be attached.")
A("")
A("## 2. Steps 1–2: builds, `is_tight_base`, selftest")
A("")
A("Engine: built unmodified with the packet's command, no warnings or errors. "
  "Cascade: the unpatched file fails to compile for K = 15 at line 71, as the packet says. My patch is that one line only:")
A("")
A("```")
A(diff_patch)
A("```")
A("")
A("**Is `is_tight_base` used anywhere that decides whether a row survives? No.** Line numbers are those of `cascade_filter_k.cpp`:")
A("")
A("- Defined at lines 146–161. It reads only `tight_keys` (built at 126–144; built in `main` at line 873).")
A("- Called at line 367 (exact build) and line 401 (the `CASCADE_CONSERVATIVE` build, not compiled here). In both places the result is passed straight to `print_base_prefix` (341–348), which only prints `tight=YES` or `tight=no` (line 347).")
A("- Called at lines 758 and 772, inside `run_selftest`.")
A("- No other use. What decides survival: level 2 is `cover_cube` in `process` (lines 468–475) and the inline cover in `process_ext` (lines 529–573); deeper levels are `q2_proper_parent` and `cover_cube_lift` inside `dfs_lifts` (lines 318–339). None of these reads `tight_keys` or calls `is_tight_base`, and the printed l2, l4, l8, l16 counts do not depend on it either.")
A("")
A("So the chair's answer (labels and selftest only) is correct. The reason line 71 exists: `is_tight_base` returns false for any base with a repeated class (line 158), which is only right when 2K < P. At P = 29 and K = 15 the reference orbit itself has a repeat (14 and 15 fold to the same class), so the positive test fails. At P = 239 the condition 2K = 30 < P holds.")
A("")
A("Selftest outputs, as printed:")
A("")
A("```")
A(f"$ ./cascade_k15p --selftest                      (exit code {rc_plain})")
A(st_plain)
A(f"$ variant A: tight primes {{31, 37, 167}}, tree primes {{37, 43}}   (exit code {rc_a})")
A(st_a)
A(f"$ variant B: tight primes {{31, 37, 167}} only, tree primes left at {{29, 61}}   (exit code {rc_b})")
A(st_b)
A(f"$ control: unmodified source built with -DK=14   (exit code {rc_k14})")
A(st_k14)
A("```")
A("")
A("Variant A is the same change the chair describes. Variant B is mine, and it shows why the second prime change is needed: with the tree primes left at {29, 61} the selftest says OK but has checked the lift kernel on **0** parents, so it would have tested nothing. With {37, 43} it checks 8,000 parents.")
A("")
A("## 3. Step 3: precondition")
A("")
A("```")
A("$ ./bgk15 239 km1low 13 out/km1low_239.txt")
A(pre_line)
A("```")
A("")
A(f"The output file is empty (0 rows). The chair's line was `{chair_pre}`: same `canonical=0` and same `nodes`.")
A("")
A("## 4. Step 4: totals")
A("")
A("My own driver is `fb_driver.py` (in the evidence bundle). It was written before I opened any chair file and shares nothing with `kcascade_run.py`.")
A("")
A("| | Irredundant branch | Reducible branch |")
A("|---|---|---|")
A(f"| jobs | {isum['jobs_finished']} (r, s) jobs over 14 roots | {ks['roots']} km1 roots |")
A(f"| rows | {n(isum['rows'])} | {n(ks['rooted_covers'])} rooted covers → {n(ks['distinct_covers'])} distinct → {n(ks['casc_rows'])} extension rows |")
A(f"| engine nodes | {n(isum['nodes'])} | {n(ks['nodes_total'])} |")
A(f"| rows surviving level 2 | {n(isum['l2_survivors'])} | {n(ks['l2_survivors'])} |")
A(f"| rows alive at level 4 | {isum['alive_l4']} | {ks['alive_l4']} |")
A(f"| rows alive at level 8 | {isum['alive_l8']} | {ks['alive_l8']} |")
A(f"| **rows alive at level 16** | **{isum['alive_l16']}** | **{ks['alive_l16']}** |")
A(f"| generation CPU-seconds | {isum['gen_secs_total']:.0f} | {ks['gen_secs_total']:.0f} |")
A("")
A("\"Alive at level N\" means the SURVIVOR line of that row has a non-zero `lN=` count. For every irredundant job the row count was checked three ways (engine's printed count, line count of the rows file, cascade's `TOTAL rows=`); all agree. For the reducible branch the cascade row count equals 8,272 × 119.")
A("")
A("Only two rows in the whole gate get past level 2:")
A("")
A("```")
for l in deep_ir:
    A(f"irredundant, job (r, s) = {deep_ir_job[0]}:  {l}")
for l in deep_ext:
    A(f"reducible:  {l}")
A("```")
A("")
A("The first is the tight orbit 1..15 (the only `tight=YES` line in either branch); it is dead at level 16. The second is dead at level 8.")
A("")
A("## 5. Step 5: comparison with the chair's files")
A("")
A(f"Order of events (all times +08, from tool output): driver start {t_start[:19]}; reducible branch done {t_km1[:19]}; "
  f"irredundant branch done {t_end[:19]}; my result files hashed {frozen[-1]}; chair's repository cloned only after that "
  f"(together-mailbox HEAD `{chair_head}`). The chair's six files pass their own `SHA256SUMS`.")
A("")
A("My result files as hashed before step 5:")
A("")
A("```")
for l in frozen[:-1]:
    A(l)
A("```")
A("")
A("Output of my comparison script (`fb_compare.py`), unedited:")
A("")
A("```")
A(compare_txt)
A("```")
A("")
A("The chair's km1 file keeps all 20,635 SURVIVOR lines of the reducible branch; mine are identical, line for line and in the same order. "
  "The chair's km1 file has no per-root rows or nodes, so that branch cannot be compared root by root; my per-root values are in Appendix B for whoever runs it next.")
A("")
A(f"**Verdict: {verdict}.**")
A("")
A("## 6. What this test does and does not show")
A("")
A("- It shows the chair's numbers are not an accident of one run: a second seat with its own driver gets the same rows and nodes for every job, and the same cascade result.")
A("- It does not show that the engine is complete at K = 15. Both seats ran the same sources. The engine's header names a validation gate for K = 13 and the author's campaign ran K = 14; I found no K = 15 validation in the three files I was told to use. The chair's own SUMMARY.txt already says \"scouting build; not a certificate\"; I agree with that wording.")
A(f"- I cannot confirm that the machines differ. The chair's folder records no CPU model, compiler version or binary hashes. The timings are very close (precondition: mine {pre_line.split('secs=')[1]} s, chair {chair_pre.split('secs=')[1]} s; km1 generation: mine {ks['gen_secs_total']:.0f} s, chair {ck['gen_secs']:.0f} s), which suggests the same kind of cloud machine. It was a different instance, but probably not different hardware or a different compiler. Suggestion: the chair adds `lscpu`, `g++ --version` and the sha256 of its two binaries to its folder.")
A("- Small wording difference: the chair's `cascade_k15_scouting_patch.diff` has a different message string on line 71 than the packet text. The condition (`2 * K < 89`) is the same, so it has no effect.")
A("")
A("## 7. Extra checks (not asked for in the packet)")
A("")
A("**A. Independent re-computation of the cascade.** Because the cascade's own selftest cannot run unchanged at K = 15, I wrote `fb_oracle.py`, a separate Python program that recomputes l2, l4, l8, l16, l32 for a row directly from the covering condition in the file header. It uses every time T (not only odd T) and a different search method, and shares no code with the C++.")
A("")
A("```")
for f in ("ir_all_survivors", "ir_rows_sample", "km1_all_survivors", "km1_extrows_sample"):
    A(oracle[f])
A("```")
A("")
A("So every one of the 35,819 SURVIVOR lines is reproduced exactly, and 8,000 random rows (7,917 of them non-survivors) come out the same as the cascade says. The 5 sampled irredundant jobs were chosen by me to spread over roots 0, 3, 7, 10, 13; rows inside each were drawn with seed 20261004. This checks the cascade program, not the generator.")
A("")
A("**B. Different compiler and code path.** To add the machine difference that I could not confirm, I rebuilt the same sources with clang++ and `-march=x86-64-v3` (no AVX-512, so the engine prints `VEC=0`), and re-ran all 14 km1 roots plus 20 irredundant jobs drawn with `random.Random(239).sample`. Each rows file must be byte-identical to the main run's.")
A("")
A("```")
A(f"compiler: {clang}")
A(alt_info)
A(alt_pick)
A(alt_final)
A("```")
A("")
A("**C. The engine's own cross-check at K = 15.** The engine has a mode `both` that builds the level-one family twice, by direct enumeration and by the decomposition used above, and compares them. It is only affordable at small primes. With the same `bgk15` binary:")
A("")
A("```")
for l in open(f"{OUT}/both_small_primes.txt"):
    if "missing=" in l:
        A(l.rstrip())
A("```")
A("")
A("The two methods agree at all five primes. This is the program checking itself at small p, so it is weak evidence about p = 239, but it is the only K = 15 check of the generator I could run cheaply.")
A("")
A("## 8. Evidence bundle")
A("")
A("`fable_b_test4_evidence.zip` holds: my driver, comparison, oracle and alt-check scripts; `ir_jobs.jsonl` (one line per job, with the sha256 of each rows file); `km1_jobs.jsonl`; both summaries; the driver log; every cascade output; the oracle and alt-check outputs. The rows files themselves (about 300 MB) are not in the bundle; their hashes are.")
A("")
A("| Script / extra binary | sha256 |")
A("|---|---|")
for f in ("fb_driver.py", "fb_compare.py", "fb_oracle.py", "fb_altcheck.py", "bgk15_clang_novec", "cascade_k15p_clang"):
    A(f"| {f} | `{H[f]}` |")
A("")
A("No keys or passwords were used. I did not search or read other chats.")
A("")
A("## Appendix A. Irredundant branch, job by job")
A("")
A("`= chair` compares rows and nodes with the chair's line for the same (r, s).")
A("")
A("| r | s | rows | nodes | level-2 survivors | alive at level 16 | = chair |")
A("|---|---|---|---|---|---|---|")
for k in sorted(ir):
    d = ir[k]
    same = k in chair and d["rows"] == chair[k]["rows"] and d["nodes"] == chair[k]["nodes"]
    A(f"| {k[0]} | {k[1]} | {n(d['rows'])} | {n(d['nodes'])} | {d['l2_survivors']} | {d['alive_l16']} | {'yes' if same else 'NO'} |")
A(f"| **all** | **149** | **{n(isum['rows'])}** | **{n(isum['nodes'])}** | **{n(isum['l2_survivors'])}** | **{isum['alive_l16']}** | **{149 - ndiff}/149** |")
A("")
A("## Appendix B. Reducible branch, root by root")
A("")
A("| r | root class | rooted covers | nodes |")
A("|---|---|---|---|")
for r in sorted(km):
    A(f"| {r} | {ks['root_values'][r]} | {n(km[r]['covers'])} | {n(km[r]['nodes'])} |")
A(f"| **all** | | **{n(ks['rooted_covers'])}** (distinct: {n(ks['distinct_covers'])}) | **{n(ks['nodes_total'])}** |")
A("")
A(f"sha256 of my deduplicated cover file (8,272 lines, sorted): `{ks['dedup_sha256']}`")
A("")
A("END PT005-TEST4-REPORT")

open(DEST, "w").write("\n".join(L) + "\n")
print("written", DEST, len(L), "lines")
