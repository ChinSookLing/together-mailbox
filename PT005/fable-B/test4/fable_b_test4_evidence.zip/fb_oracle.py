#!/usr/bin/env python3
"""
fb_oracle.py -- Fable-B's independent re-computation of the binary cascade
for single rows (EXTRA check, not asked for in the packet).

It shares no code with cascade_filter_k.cpp. It works straight from the
covering condition in that file's header comment:

    residue v is GOOD at time T on level N  iff  (K+1) * dist_N(T*v) >= N
    a vector is IMPROPER on level N         iff  no time T makes all K good

  * every time T = 1..N/2 is used (the C++ lift kernel uses odd T only);
  * the vectors are found by a depth-first search over the K coordinates
    that carries the set of still-good times as one Python big integer
    (the C++ code unions sub-cubes into a 2^K bitmap instead).

Level 2 follows the C++ convention: lifts with at most one odd coordinate
are screened out before counting ("pre-odd screen").

usage:
  fb_oracle.py P survivors CASC_OUT_FILE...   re-derive every SURVIVOR line
  fb_oracle.py P rows N SEED ROWS_FILE CASC_OUT_FILE
                                              N random rows of one job; rows
                                              without a SURVIVOR line must come
                                              out fully proper at level 2
"""
import random
import re
import sys

K = 15
KP1 = K + 1
TOP = 5                      # levels 2^1 .. 2^5, as MAX_LIFT_EXP in the C++


def good_mask(v, N, tmax):
    """bit (T-1) set iff residue v is good at time T on level N."""
    m = 0
    for T in range(1, tmax + 1):
        y = (T * v) % N
        d = y if y <= N - y else N - y
        if KP1 * d >= N:
            m |= 1 << (T - 1)
    return m


def improper_choices(masks, tmax):
    """masks[i][b] = good-time mask of coordinate i under choice b.
    Returns every choice vector (as an int, bit i = choice of coord i) for
    which no time is good for all coordinates."""
    full = (1 << tmax) - 1
    res = []
    n = len(masks)

    def walk(i, alive, code):
        if alive == 0:
            # no good time left: every completion is improper
            rest = n - i
            for tail in range(1 << rest):
                res.append(code | (tail << i))
            return
        if i == n:
            return
        walk(i + 1, alive & masks[i][0], code)
        walk(i + 1, alive & masks[i][1], code | (1 << i))

    walk(0, full, 0)
    return res


def cascade_counts(base, P):
    """base: K folded classes (1..(P-1)/2). Returns [l2, l4, l8, l16, l32]."""
    N = 2 * P
    lifts = []
    masks = []
    for c in base:
        pair = [c if c % 2 == b else c + P for b in (0, 1)]   # choice b = parity b
        lifts.append(pair)
        masks.append([good_mask(pair[0], N, P), good_mask(pair[1], N, P)])
    imp = [a for a in improper_choices(masks, P) if bin(a).count("1") >= 2]
    counts = [len(imp), 0, 0, 0, 0]
    cur = [[lifts[i][(a >> i) & 1] for i in range(K)] for a in imp]
    M = N
    for depth in range(1, TOP):
        nxt = []
        N2 = 2 * M
        for w in cur:
            if sum(1 for x in w if x % 2 == 0) >= K - 1:
                continue
            masks = [[good_mask(x, N2, M), good_mask(x + M, N2, M)] for x in w]
            for a in improper_choices(masks, M):
                nxt.append([w[i] + (M if (a >> i) & 1 else 0) for i in range(K)])
        counts[depth] = len(nxt)
        cur = nxt
        M = N2
        if not cur:
            break
    return counts


LINE = re.compile(r"^SURVIVOR base:((?: \d+)+) l2=(\d+) tight=(?:YES|no)(.*)$")


def parse_line(line):
    g = LINE.match(line.rstrip("\n"))
    base = [int(x) for x in g.group(1).split()]
    got = [int(g.group(2)), 0, 0, 0, 0]
    for lv, n in re.findall(r" l(\d+)=(\d+)", g.group(3)):
        got[{4: 1, 8: 2, 16: 3, 32: 4}[int(lv)]] = int(n)
    return base, got


def main():
    P = int(sys.argv[1])
    mode = sys.argv[2]
    bad = 0
    if mode == "survivors":
        n = 0
        for fn in sys.argv[3:]:
            for line in open(fn):
                if not line.strip():
                    continue
                base, got = parse_line(line)
                mine = cascade_counts(base, P)
                n += 1
                if mine != got:
                    bad += 1
                    print(f"DIFF {fn}: base={base} cascade={got} oracle={mine}")
        print(f"ORACLE survivors checked={n} differing={bad}")
    elif mode == "rows":
        nsamp, seed, rowsf, cascf = int(sys.argv[3]), int(sys.argv[4]), sys.argv[5], sys.argv[6]
        want = {}
        for line in open(cascf):
            if line.strip():
                base, got = parse_line(line)
                want[tuple(base)] = got
        rows = [l.strip() for l in open(rowsf) if l.strip()]
        rng = random.Random(seed)
        pick = rng.sample(range(len(rows)), min(nsamp, len(rows)))
        nsurv = 0
        for j in pick:
            h = rows[j]
            base = [int(h[2 * i:2 * i + 2], 16) for i in range(len(h) // 2)]
            if len(base) != K:
                raise SystemExit("row is not K classes: " + h)
            mine = cascade_counts(base, P)
            got = want.get(tuple(base), [0, 0, 0, 0, 0])
            nsurv += tuple(base) in want
            if mine != got:
                bad += 1
                print(f"DIFF {rowsf} row {j}: base={base} cascade={got} oracle={mine}")
        print(f"ORACLE rows file={rowsf} total_rows={len(rows)} sampled={len(pick)} seed={seed} "
              f"of_which_survivors={nsurv} differing={bad}")
    elif mode == "extrows":
        # N random (14-class cover, extension class v) pairs of the reducible branch
        nsamp, seed, rowsf, cascf = int(sys.argv[3]), int(sys.argv[4]), sys.argv[5], sys.argv[6]
        want = {}
        for line in open(cascf):
            if line.strip():
                base, got = parse_line(line)
                want[tuple(base)] = got
        rows = [l.strip() for l in open(rowsf) if l.strip()]
        NC = (P - 1) // 2
        rng = random.Random(seed)
        nsurv = 0
        for _ in range(nsamp):
            h = rows[rng.randrange(len(rows))]
            base = [int(h[2 * i:2 * i + 2], 16) for i in range(len(h) // 2)]
            if len(base) != K - 1:
                raise SystemExit("row is not K-1 classes: " + h)
            base.append(rng.randint(1, NC))
            mine = cascade_counts(base, P)
            got = want.get(tuple(base), [0, 0, 0, 0, 0])
            nsurv += tuple(base) in want
            if mine != got:
                bad += 1
                print(f"DIFF {rowsf}: base={base} cascade={got} oracle={mine}")
        print(f"ORACLE extrows file={rowsf} covers={len(rows)} sampled={nsamp} seed={seed} "
              f"of_which_survivors={nsurv} differing={bad}")
    else:
        raise SystemExit("bad mode")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
